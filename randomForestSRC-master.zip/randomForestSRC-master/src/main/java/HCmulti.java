package com.kogalur.randomforest;

class HCmulti {

    int[] hcDim;
    double[] contPTR;

    HCmulti (int[] hcDim, double[] contPTR) {
        this.hcDim = hcDim;
        this.contPTR = contPTR;
    }
}
