package com.kogalur.randomforest;

enum ModelType {
    MINI, MIDI, MAXI, REST, PRED
}
