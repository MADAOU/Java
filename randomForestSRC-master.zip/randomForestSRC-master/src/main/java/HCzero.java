package com.kogalur.randomforest;

class HCzero {

    int[] parmID;
    double[] contPT;
    int[] mwcpSZ;
    int[] mwcpPT;

    HCzero (int[] parmID, double[] contPT, int[] mwcpSZ, int[]mwcpPT) {
        this.parmID = parmID;
        this.contPT = contPT;
        this.mwcpSZ = mwcpSZ;
        this.mwcpPT = mwcpPT;
    }
}
