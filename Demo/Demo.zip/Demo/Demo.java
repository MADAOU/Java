import java.math.*;
import java.util.*;
public class Demo{
 
public static void main(String[] args) {
 
    Integer times= null;
 
    Runtime run = Runtime.getRuntime();
    boolean flg=true;
    System.out.println("Please input the time of shutdown(seconds)");
 while(flg){
	try {
 	Scanner sc=new Scanner(System.in);
	times=Integer.parseInt(sc.next());
        Process process = run.exec("cmd.exe /k start shutdown /s /t " +times);
        //process.waitFor();
	flg=false;
        System.out.println("Programe is starting and the computer will shutdown in "
                    + times +" seconds");
    	} catch (Exception e) {
        flg=true;
    	}
} 
 
}
 
}
